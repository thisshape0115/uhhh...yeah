package com.locker.app.activities

import android.app.KeyguardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.locker.app.R
import com.locker.app.utils.LockPreferences
import com.locker.app.views.DrawingView
import com.locker.app.views.PatternView
import com.locker.app.views.ZipperView

class LockScreenActivity : AppCompatActivity() {

    private var mode: String = "lock"   // "lock" or "verify_to_change"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mode = intent.getStringExtra("mode") ?: "lock"

        // Show above lock screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        // Dismiss keyguard
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            km.requestDismissKeyguard(this, null)
        }

        val lockType = LockPreferences.getLockType(this)
        when (lockType) {
            LockPreferences.LOCK_TYPE_PATTERN_4X4 -> showPatternLock()
            LockPreferences.LOCK_TYPE_DRAWING -> showDrawingLock()
            LockPreferences.LOCK_TYPE_ZIPPER -> showZipperLock()
            else -> unlockSuccess()
        }
    }

    override fun onBackPressed() {
        // Prevent back on lock screen
    }

    private fun showPatternLock() {
        setContentView(R.layout.activity_lock_screen_pattern)

        val patternView = findViewById<PatternView>(R.id.lockPatternView)
        val tvMessage = findViewById<TextView>(R.id.tvLockMessage)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnRetry = findViewById<Button>(R.id.btnRetry)
        btnSave.visibility = View.GONE
        btnRetry.visibility = View.GONE

        patternView.isSetupMode = false
        patternView.onPatternComplete = { drawnPattern ->
            val saved = LockPreferences.getPattern(this)
            if (drawnPattern == saved) {
                unlockSuccess()
            } else {
                tvMessage.text = "패턴이 틀렸습니다"
                patternView.clearPattern()
            }
        }
    }

    private fun showDrawingLock() {
        setContentView(R.layout.activity_lock_screen_drawing)

        val drawingView = findViewById<DrawingView>(R.id.lockDrawingView)

        drawingView.showYellowLine = false  // No yellow line on lock screen

        drawingView.onDrawingFinished = {
            val savedPaths = LockPreferences.getDrawingPaths(this)
            if (drawingView.verifyDrawing(savedPaths)) {
                unlockSuccess()
            } else {
                // Wrong drawing: clear silently, no UI feedback, user can try again
                drawingView.clearAll()
            }
        }
        // onDrawingResumed not needed on lock screen (no buttons to hide)
    }

    private fun showZipperLock() {
        setContentView(R.layout.activity_lock_screen_zipper)

        val zipperView = findViewById<ZipperView>(R.id.zipperView)
        zipperView.onUnlocked = {
            unlockSuccess()
        }
    }

    private fun unlockSuccess() {
        if (mode == "verify_to_change") {
            // Go to lock type selection to change lock
            val intent = Intent(this, LockTypeSelectionActivity::class.java)
            startActivity(intent)
        }
        finish()
    }
}
