package com.locker.app.utils

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Path
import android.graphics.PointF
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object LockPreferences {

    private const val PREFS_NAME = "locker_prefs"
    private const val KEY_LOCK_TYPE = "lock_type"
    private const val KEY_PATTERN_NODES = "pattern_nodes"
    private const val KEY_DRAWING_PATHS = "drawing_paths"
    private const val KEY_LOCK_ENABLED = "lock_enabled"

    const val LOCK_TYPE_NONE = 0
    const val LOCK_TYPE_PATTERN_4X4 = 1
    const val LOCK_TYPE_DRAWING = 2
    const val LOCK_TYPE_ZIPPER = 3

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun setLockType(context: Context, type: Int) {
        prefs(context).edit().putInt(KEY_LOCK_TYPE, type).apply()
    }

    fun getLockType(context: Context): Int =
        prefs(context).getInt(KEY_LOCK_TYPE, LOCK_TYPE_NONE)

    fun setLockEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_LOCK_ENABLED, enabled).apply()
    }

    fun isLockEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_LOCK_ENABLED, false)

    // Pattern: store as list of node indices (0-15 for 4x4)
    fun savePattern(context: Context, pattern: List<Int>) {
        val json = Gson().toJson(pattern)
        prefs(context).edit().putString(KEY_PATTERN_NODES, json).apply()
    }

    fun getPattern(context: Context): List<Int> {
        val json = prefs(context).getString(KEY_PATTERN_NODES, null) ?: return emptyList()
        val type = object : TypeToken<List<Int>>() {}.type
        return Gson().fromJson(json, type)
    }

    // Drawing: store as list of path point lists
    fun saveDrawingPaths(context: Context, paths: List<List<PointFData>>) {
        val json = Gson().toJson(paths)
        prefs(context).edit().putString(KEY_DRAWING_PATHS, json).apply()
    }

    fun getDrawingPaths(context: Context): List<List<PointFData>> {
        val json = prefs(context).getString(KEY_DRAWING_PATHS, null) ?: return emptyList()
        val type = object : TypeToken<List<List<PointFData>>>() {}.type
        return Gson().fromJson(json, type)
    }

    data class PointFData(val x: Float, val y: Float)
}
