package com.locker.app.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.locker.app.activities.LockScreenActivity
import com.locker.app.utils.LockPreferences

class ScreenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!LockPreferences.isLockEnabled(context)) return
        if (LockPreferences.getLockType(context) == LockPreferences.LOCK_TYPE_NONE) return

        when (intent.action) {
            Intent.ACTION_SCREEN_ON -> {
                val lockIntent = Intent(context, LockScreenActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(lockIntent)
            }
        }
    }
}
