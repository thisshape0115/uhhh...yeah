package com.locker.app.views

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import kotlin.math.*

class ZipperView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onUnlocked: (() -> Unit)? = null

    // Zipper position: 0.0 = top (locked), 1.0 = bottom (unlocked)
    private var zipProgress = 0f      // 0..1
    private var handleY = 0f          // current handle Y pixel
    private var startY = 0f           // zipper track start Y
    private var endY = 0f             // zipper track end Y
    private val trackX get() = width / 2f

    // Handle physics
    private var handleAngle = 0f       // rotation of handle graphic
    private var isDragging = false
    private var lastDragY = 0f
    private var dragVelocity = 0f
    private var wobbleAnimator: ValueAnimator? = null
    private var wobbleOffset = 0f

    // Teeth drawn on both sides
    private val teethPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C0C0C0")
        style = Paint.Style.FILL
    }
    private val teethHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E8E8E8")
        style = Paint.Style.FILL
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#888888")
        strokeWidth = 8f
        style = Paint.Style.STROKE
    }
    private val trackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#666666")
        style = Paint.Style.FILL
    }
    private val gapPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#222222")
        style = Paint.Style.FILL
    }

    // Handle paints
    private val handleBodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B0B0B0")
        style = Paint.Style.FILL
    }
    private val handleShinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EEEEEE")
        style = Paint.Style.FILL
        alpha = 180
    }
    private val handleRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#888888")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val handleHolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#444444")
        style = Paint.Style.FILL
    }
    private val pullerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#999999")
        strokeWidth = 6f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    // Shader for background
    private var backgroundShader: Shader? = null

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        startY = h * 0.08f
        endY = h * 0.92f
        handleY = startY
        buildBackgroundShader(w, h)
    }

    private fun buildBackgroundShader(w: Int, h: Int) {
        // Watercolor-like blobs: red, orange, yellow, deep red
        val colors = intArrayOf(
            Color.parseColor("#C0392B"),   // red
            Color.parseColor("#E74C3C"),   // light red
            Color.parseColor("#E67E22"),   // orange
            Color.parseColor("#F39C12"),   // yellow-orange
            Color.parseColor("#F1C40F"),   // yellow
            Color.parseColor("#922B21"),   // dark red
            Color.parseColor("#D35400"),   // burnt orange
            Color.parseColor("#CB4335"),   // mid red
        )
        val positions = floatArrayOf(0f, 0.15f, 0.3f, 0.48f, 0.62f, 0.75f, 0.88f, 1f)
        // Diagonal gradient to simulate flowing watercolor
        backgroundShader = LinearGradient(
            w * 0.1f, 0f, w * 0.9f, h.toFloat(),
            colors, positions, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        // Draw watercolor background
        drawWatercolorBackground(canvas)

        val closedUntil = handleY
        val openFrom = handleY

        // Draw zipped (closed) portion - teeth meshed together above handle
        drawClosedZipper(canvas, startY, closedUntil)

        // Draw open portion - two tracks separating below handle
        drawOpenZipper(canvas, openFrom, endY)

        // Draw handle
        drawZipperHandle(canvas, trackX, handleY + wobbleOffset, handleAngle)

        // Unlock hint arrow at bottom
        if (!isDragging && zipProgress < 0.1f) {
            drawUnlockHint(canvas)
        }
    }

    private fun drawWatercolorBackground(canvas: Canvas) {
        val bgPaint = Paint().apply { shader = backgroundShader }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Draw soft watercolor blobs overlaid
        drawWatercolorBlobs(canvas)
    }

    private fun drawWatercolorBlobs(canvas: Canvas) {
        val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            alpha = 55
        }
        val w = width.toFloat()
        val h = height.toFloat()

        // Orange blob top-left
        blobPaint.color = Color.parseColor("#FF7800")
        blobPaint.alpha = 50
        canvas.drawOval(RectF(-w*0.1f, h*0.05f, w*0.5f, h*0.45f), blobPaint)

        // Yellow blob center-right
        blobPaint.color = Color.parseColor("#FFD700")
        blobPaint.alpha = 40
        canvas.drawOval(RectF(w*0.4f, h*0.2f, w*1.1f, h*0.7f), blobPaint)

        // Deep red blob bottom
        blobPaint.color = Color.parseColor("#8B0000")
        blobPaint.alpha = 60
        canvas.drawOval(RectF(w*0.05f, h*0.6f, w*0.9f, h*1.1f), blobPaint)

        // Light orange blob top-right
        blobPaint.color = Color.parseColor("#FF6347")
        blobPaint.alpha = 35
        canvas.drawOval(RectF(w*0.5f, -h*0.1f, w*1.1f, h*0.4f), blobPaint)
    }

    private fun drawClosedZipper(canvas: Canvas, fromY: Float, toY: Float) {
        if (toY <= fromY) return
        val cx = trackX
        val trackW = 18f
        val teethW = 22f
        val teethH = 14f
        val teethSpacing = 18f

        // Central tape
        val tapePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#777777")
            style = Paint.Style.FILL
        }
        canvas.drawRect(cx - trackW / 2, fromY, cx + trackW / 2, toY, tapePaint)

        // Meshed teeth
        var y = fromY
        while (y < toY) {
            // Left tooth
            val leftRect = RectF(cx - teethW, y, cx, y + teethH)
            canvas.drawRoundRect(leftRect, 4f, 4f, teethPaint)
            val lHighlight = RectF(leftRect.left + 3, leftRect.top + 2, leftRect.right - 4, leftRect.top + 5)
            canvas.drawRoundRect(lHighlight, 2f, 2f, teethHighlightPaint)

            // Right tooth
            val rightRect = RectF(cx, y, cx + teethW, y + teethH)
            canvas.drawRoundRect(rightRect, 4f, 4f, teethPaint)
            val rHighlight = RectF(rightRect.left + 4, rightRect.top + 2, rightRect.right - 3, rightRect.top + 5)
            canvas.drawRoundRect(rHighlight, 2f, 2f, teethHighlightPaint)

            y += teethSpacing
        }
    }

    private fun drawOpenZipper(canvas: Canvas, fromY: Float, toY: Float) {
        if (toY <= fromY) return
        val cx = trackX
        val spread = 55f      // how far apart the tracks are at bottom
        val teethW = 16f
        val teethH = 12f
        val teethSpacing = 18f
        val trackW = 10f

        var y = fromY
        while (y < toY) {
            val t = ((y - fromY) / (toY - fromY)).coerceIn(0f, 1f)
            val offset = spread * t * t    // quadratic spread

            // Left track rail
            val lx = cx - offset
            val leftTooth = RectF(lx - teethW, y, lx, y + teethH)
            canvas.drawRoundRect(leftTooth, 3f, 3f, teethPaint)

            // Right track rail
            val rx = cx + offset
            val rightTooth = RectF(rx, y, rx + teethW, y + teethH)
            canvas.drawRoundRect(rightTooth, 3f, 3f, teethPaint)

            // Track rails
            canvas.drawRect(lx - trackW, y, lx, y + teethH, trackFillPaint)
            canvas.drawRect(rx, y, rx + trackW, y + teethH, trackFillPaint)

            y += teethSpacing
        }

        // Gap in the middle (open area)
        val gapPt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            alpha = 40
            style = Paint.Style.FILL
        }
        val path = Path()
        path.moveTo(cx, fromY)
        path.lineTo(cx - spread, toY)
        path.lineTo(cx + spread, toY)
        path.close()
        canvas.drawPath(path, gapPt)
    }

    private fun drawZipperHandle(canvas: Canvas, cx: Float, cy: Float, angle: Float) {
        canvas.save()
        canvas.rotate(angle, cx, cy)

        val hw = 38f    // half-width
        val hh = 28f    // half-height

        // Slider body (diamond/trapezoidal shape)
        val sliderPath = Path()
        sliderPath.moveTo(cx - hw, cy - 8f)
        sliderPath.lineTo(cx + hw, cy - 8f)
        sliderPath.lineTo(cx + hw * 0.7f, cy + hh)
        sliderPath.lineTo(cx - hw * 0.7f, cy + hh)
        sliderPath.close()

        // Shadow
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            alpha = 80
            style = Paint.Style.FILL
        }
        canvas.save()
        canvas.translate(3f, 4f)
        canvas.drawPath(sliderPath, shadowPaint)
        canvas.restore()

        // Body gradient
        val bodyGradient = LinearGradient(
            cx - hw, cy - 8f, cx + hw, cy + hh,
            intArrayOf(Color.parseColor("#D5D5D5"), Color.parseColor("#9A9A9A")),
            null, Shader.TileMode.CLAMP
        )
        handleBodyPaint.shader = bodyGradient
        canvas.drawPath(sliderPath, handleBodyPaint)
        canvas.drawPath(sliderPath, handleRimPaint)

        // Shine
        val shinePath = Path()
        shinePath.moveTo(cx - hw + 6, cy - 6f)
        shinePath.lineTo(cx + hw - 6, cy - 6f)
        shinePath.lineTo(cx + hw * 0.6f, cy + 10f)
        shinePath.lineTo(cx - hw * 0.6f, cy + 10f)
        shinePath.close()
        canvas.drawPath(shinePath, handleShinePaint)

        // Center hole
        canvas.drawOval(RectF(cx - 8f, cy, cx + 8f, cy + 16f), handleHolePaint)

        // Puller tab above handle
        canvas.drawLine(cx, cy - 8f, cx, cy - 40f, pullerPaint)
        canvas.drawOval(RectF(cx - 14f, cy - 58f, cx + 14f, cy - 36f), handleBodyPaint)
        canvas.drawOval(RectF(cx - 14f, cy - 58f, cx + 14f, cy - 36f), handleRimPaint)
        canvas.drawCircle(cx, cy - 47f, 5f, handleHolePaint)

        canvas.restore()
    }

    private fun drawUnlockHint(canvas: Canvas) {
        val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            alpha = (180 * (sin(System.currentTimeMillis() / 600.0) * 0.5 + 0.5)).toInt()
            textSize = 36f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("↓ 아래로 당기기", width / 2f, height * 0.88f, hintPaint)
        invalidate()
    }

    // Touch handling
    private val handleHitRadius = 80f

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val hx = trackX
        val hy = handleY

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val dist = sqrt(((event.x - hx).pow(2) + (event.y - hy).pow(2)).toDouble()).toFloat()
                if (dist <= handleHitRadius) {
                    isDragging = true
                    lastDragY = event.y
                    wobbleAnimator?.cancel()
                    dragVelocity = 0f
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDragging) {
                    val dy = event.y - lastDragY
                    dragVelocity = dy
                    lastDragY = event.y

                    // Calculate angle based on horizontal deviation
                    val dx = event.x - hx
                    handleAngle = (dx * 0.3f).coerceIn(-30f, 30f)

                    // Move handle downward only
                    handleY = (handleY + dy).coerceIn(startY, endY)
                    zipProgress = (handleY - startY) / (endY - startY)

                    if (zipProgress >= 1f) {
                        isDragging = false
                        onUnlocked?.invoke()
                    }
                    invalidate()
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isDragging) {
                    isDragging = false
                    // Snap back to top with wobble
                    snapBackWithWobble()
                }
            }
        }
        return false
    }

    private fun snapBackWithWobble() {
        val startVal = handleY
        val animator = ValueAnimator.ofFloat(startVal, startY)
        animator.duration = 400
        animator.interpolator = OvershootInterpolator(2f)
        animator.addUpdateListener {
            handleY = it.animatedValue as Float
            zipProgress = (handleY - startY) / (endY - startY)
            invalidate()
        }
        animator.start()

        // Wobble animation
        val wobbleAnim = ValueAnimator.ofFloat(1f, 0f)
        wobbleAnim.duration = 800
        wobbleAnim.addUpdateListener {
            val t = it.animatedValue as Float
            wobbleOffset = sin(t * PI * 6).toFloat() * 10f * t
            handleAngle = sin(t * PI * 4).toFloat() * 15f * t
            invalidate()
        }
        wobbleAnim.start()
        wobbleAnimator = wobbleAnim
    }

    fun reset() {
        handleY = startY
        zipProgress = 0f
        handleAngle = 0f
        wobbleOffset = 0f
        isDragging = false
        wobbleAnimator?.cancel()
        invalidate()
    }
}
