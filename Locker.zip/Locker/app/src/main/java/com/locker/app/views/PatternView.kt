package com.locker.app.views

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.sqrt

class PatternView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var isSetupMode: Boolean = true  // true = setup, false = unlock verify
    var onPatternComplete: ((List<Int>) -> Unit)? = null

    private val dots = Array(16) { PointF() }  // 4x4 = 16 dots
    private val selectedDots = mutableListOf<Int>()
    private var touchX = 0f
    private var touchY = 0f
    private var isDrawing = false
    private var patternFinalized = false

    private val dotRadius = 18f
    private val dotRadiusSelected = 24f
    private val dotHitRadius = 50f

    private val paintDot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val paintDotSelected = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        alpha = 220
    }
    private val paintDotRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3f
        alpha = 180
    }
    private val paintLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        alpha = 180
    }
    private val paintActiveLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        alpha = 130
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val paddingH = w * 0.12f
        val paddingV = h * 0.12f
        val cellW = (w - 2 * paddingH) / 3f
        val cellH = (h - 2 * paddingV) / 3f
        for (row in 0..3) {
            for (col in 0..3) {
                val idx = row * 4 + col
                dots[idx].set(
                    paddingH + col * cellW,
                    paddingV + row * cellH
                )
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Draw connecting lines between selected dots
        for (i in 0 until selectedDots.size - 1) {
            val a = dots[selectedDots[i]]
            val b = dots[selectedDots[i + 1]]
            canvas.drawLine(a.x, a.y, b.x, b.y, paintLine)
        }

        // Draw active line from last dot to finger
        if (isDrawing && selectedDots.isNotEmpty()) {
            val last = dots[selectedDots.last()]
            canvas.drawLine(last.x, last.y, touchX, touchY, paintActiveLine)
        }

        // Draw dots
        for (i in dots.indices) {
            val dot = dots[i]
            if (selectedDots.contains(i)) {
                // Selected dot: ring + filled
                canvas.drawCircle(dot.x, dot.y, dotRadiusSelected, paintDotSelected)
                canvas.drawCircle(dot.x, dot.y, dotRadiusSelected + 8f, paintDotRing)
            } else {
                canvas.drawCircle(dot.x, dot.y, dotRadius, paintDot)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (patternFinalized) return false

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                isDrawing = true
                touchX = event.x
                touchY = event.y
                trySelectDot(event.x, event.y)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                touchX = event.x
                touchY = event.y
                trySelectDot(event.x, event.y)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDrawing = false
                patternFinalized = true
                invalidate()
                onPatternComplete?.invoke(selectedDots.toList())
            }
        }
        return true
    }

    private fun trySelectDot(x: Float, y: Float) {
        for (i in dots.indices) {
            if (selectedDots.contains(i)) continue
            val dot = dots[i]
            val dist = sqrt(((x - dot.x) * (x - dot.x) + (y - dot.y) * (y - dot.y)).toDouble()).toFloat()
            if (dist <= dotHitRadius) {
                selectedDots.add(i)
                break
            }
        }
    }

    fun clearPattern() {
        selectedDots.clear()
        isDrawing = false
        patternFinalized = false
        invalidate()
    }

    fun getPattern(): List<Int> = selectedDots.toList()

    fun verifyPattern(saved: List<Int>): Boolean = selectedDots == saved
}
