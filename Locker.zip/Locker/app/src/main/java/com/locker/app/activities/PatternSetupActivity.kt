package com.locker.app.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.locker.app.R
import com.locker.app.services.LockService
import com.locker.app.utils.LockPreferences
import com.locker.app.views.PatternView

class PatternSetupActivity : AppCompatActivity() {

    private lateinit var patternView: PatternView
    private lateinit var tvInstructions: TextView
    private lateinit var btnSave: Button
    private lateinit var btnRetry: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pattern_setup)

        patternView = findViewById(R.id.patternView)
        tvInstructions = findViewById(R.id.tvInstructions)
        btnSave = findViewById(R.id.btnSave)
        btnRetry = findViewById(R.id.btnRetry)

        tvInstructions.text = "패턴을 그려주세요 (4×4)"

        // Hide buttons initially
        btnSave.visibility = View.INVISIBLE
        btnRetry.visibility = View.INVISIBLE

        patternView.isSetupMode = true
        patternView.onPatternComplete = { pattern ->
            if (pattern.size >= 4) {
                runOnUiThread {
                    btnSave.visibility = View.VISIBLE
                    btnRetry.visibility = View.VISIBLE
                    tvInstructions.text = "패턴을 저장하거나 다시 그려주세요"
                }
            } else {
                runOnUiThread {
                    tvInstructions.text = "최소 4개의 점을 연결해주세요"
                    patternView.clearPattern()
                }
            }
        }

        btnSave.setOnClickListener {
            val pattern = patternView.getPattern()
            if (pattern.size >= 4) {
                LockPreferences.savePattern(this, pattern)
                LockPreferences.setLockType(this, LockPreferences.LOCK_TYPE_PATTERN_4X4)
                LockPreferences.setLockEnabled(this, true)
                startLockService()
                finish()
            }
        }

        btnRetry.setOnClickListener {
            patternView.clearPattern()
            btnSave.visibility = View.INVISIBLE
            btnRetry.visibility = View.INVISIBLE
            tvInstructions.text = "패턴을 그려주세요 (4×4)"
        }
    }

    private fun startLockService() {
        val serviceIntent = Intent(this, LockService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
}
