package com.locker.app.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import com.locker.app.R
import com.locker.app.services.LockService
import com.locker.app.utils.LockPreferences

class LockTypeSelectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock_type_selection)

        val radioGroup = findViewById<RadioGroup>(R.id.radioGroupLockType)
        val btnConfirm = findViewById<Button>(R.id.btnConfirm)

        btnConfirm.setOnClickListener {
            when (radioGroup.checkedRadioButtonId) {
                R.id.radioPattern4x4 -> {
                    val intent = Intent(this, PatternSetupActivity::class.java)
                    startActivity(intent)
                    finish()
                }
                R.id.radioDrawing -> {
                    val intent = Intent(this, DrawingSetupActivity::class.java)
                    startActivity(intent)
                    finish()
                }
                R.id.radioZipper -> {
                    // Zipper needs no setup, just save type and start service
                    LockPreferences.setLockType(this, LockPreferences.LOCK_TYPE_ZIPPER)
                    LockPreferences.setLockEnabled(this, true)
                    startLockService()
                    finish()
                }
                else -> {
                    // No selection
                }
            }
        }
    }

    private fun startLockService() {
        val serviceIntent = Intent(this, LockService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
}
