package com.locker.app.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.locker.app.R
import com.locker.app.services.LockService
import com.locker.app.utils.LockPreferences
import com.locker.app.views.DrawingView

class DrawingSetupActivity : AppCompatActivity() {

    private lateinit var drawingView: DrawingView
    private lateinit var btnSave: Button
    private lateinit var btnRetry: Button
    private lateinit var tvInstruction: TextView
    private lateinit var tvHint: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawing_setup)

        drawingView = findViewById(R.id.drawingView)
        btnSave = findViewById(R.id.btnSave)
        btnRetry = findViewById(R.id.btnRetry)
        tvInstruction = findViewById(R.id.tvInstruction)
        tvHint = findViewById(R.id.tvHint)

        // Buttons hidden initially
        btnSave.visibility = View.INVISIBLE
        btnRetry.visibility = View.INVISIBLE

        drawingView.showYellowLine = true

        // Called after 1 second pause in drawing
        drawingView.onDrawingFinished = {
            runOnUiThread {
                btnSave.visibility = View.VISIBLE
                btnRetry.visibility = View.VISIBLE
                tvHint.text = "그림이 완성되었습니다. 저장하거나 다시 그리세요."
            }
        }

        // Called when user starts drawing again before 1 second is up
        drawingView.onDrawingResumed = {
            runOnUiThread {
                btnSave.visibility = View.INVISIBLE
                btnRetry.visibility = View.INVISIBLE
                tvHint.text = "손을 뗀 후 1초 후 저장/다시 그리기 버튼이 나타납니다"
            }
        }

        btnSave.setOnClickListener {
            val paths = drawingView.getAllPathData()
            if (paths.isNotEmpty()) {
                LockPreferences.saveDrawingPaths(this, paths)
                LockPreferences.setLockType(this, LockPreferences.LOCK_TYPE_DRAWING)
                LockPreferences.setLockEnabled(this, true)
                startLockService()
                finish()
            }
        }

        btnRetry.setOnClickListener {
            drawingView.clearAll()
            btnSave.visibility = View.INVISIBLE
            btnRetry.visibility = View.INVISIBLE
            tvHint.text = "손을 뗀 후 1초 후 저장/다시 그리기 버튼이 나타납니다"
        }
    }

    private fun startLockService() {
        val serviceIntent = Intent(this, LockService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
}
