package com.locker.app.activities

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.locker.app.R
import com.locker.app.utils.LockPreferences

class MainActivity : AppCompatActivity() {

    private var overlayPermissionRequested = false
    private var setupDialogShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startPermissionFlow()
    }

    override fun onResume() {
        super.onResume()
        // After returning from overlay permission settings
        if (overlayPermissionRequested && !setupDialogShown) {
            overlayPermissionRequested = false
            showSetupDialog()
        }
    }

    private fun startPermissionFlow() {
        // Step 1: Check SYSTEM_ALERT_WINDOW (overlay) permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            showOverlayPermissionDialog()
        } else {
            showSetupDialog()
        }
    }

    private fun showOverlayPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("권한 필요")
            .setMessage("Locker가 잠금화면을 표시하려면 '다른 앱 위에 표시' 권한이 필요합니다.")
            .setCancelable(false)
            .setPositiveButton("권한 허용") { _, _ ->
                overlayPermissionRequested = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
            .setNegativeButton("앱 닫기") { _, _ ->
                finish()
            }
            .show()
    }

    private fun showSetupDialog() {
        setupDialogShown = true

        // If lock is already configured, go to current lock unlock screen before changing
        val lockType = LockPreferences.getLockType(this)
        if (LockPreferences.isLockEnabled(this) && lockType != LockPreferences.LOCK_TYPE_NONE) {
            // Must unlock current lock before changing
            val intent = Intent(this, LockScreenActivity::class.java)
            intent.putExtra("mode", "verify_to_change")
            startActivity(intent)
            return
        }

        AlertDialog.Builder(this)
            .setTitle("잠금 설정")
            .setMessage("스마트폰 잠금을 '없음'으로 설정해 주세요.\n\n(Locker가 잠금화면을 대체합니다)")
            .setCancelable(false)
            .setPositiveButton("설정") { dialog, _ ->
                dialog.dismiss()
                // Go directly to lock selection (one press = dialog closes)
                navigateToLockTypeSelection()
                // Also open system lock settings
                try {
                    val intent = Intent(Settings.ACTION_SECURITY_SETTINGS)
                    startActivity(intent)
                } catch (e: Exception) {
                    // fallback
                }
            }
            .setNegativeButton("앱 닫기") { _, _ ->
                finish()
            }
            .show()
    }

    private fun navigateToLockTypeSelection() {
        val intent = Intent(this, LockTypeSelectionActivity::class.java)
        startActivity(intent)
        finish()
    }
}
