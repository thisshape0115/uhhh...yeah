package com.locker.app.views

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.locker.app.utils.LockPreferences

class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var showYellowLine: Boolean = true   // false on lock screen
    var onDrawingFinished: (() -> Unit)? = null
    var onDrawingResumed: (() -> Unit)? = null

    // All stroke paths stored as list of point lists
    private val allStrokes = mutableListOf<MutableList<PointF>>()
    private var currentStroke = mutableListOf<PointF>()
    private val handler = Handler(Looper.getMainLooper())
    private var isFinished = false

    private val stopDrawingRunnable = Runnable {
        isFinished = true
        onDrawingFinished?.invoke()
    }

    private val paintYellow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW
        strokeWidth = 8f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!showYellowLine) return

        for (stroke in allStrokes) {
            drawStroke(canvas, stroke, paintYellow)
        }
        drawStroke(canvas, currentStroke, paintYellow)
    }

    private fun drawStroke(canvas: Canvas, points: List<PointF>, paint: Paint) {
        if (points.size < 2) return
        val path = Path()
        path.moveTo(points[0].x, points[0].y)
        for (i in 1 until points.size) {
            path.lineTo(points[i].x, points[i].y)
        }
        canvas.drawPath(path, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (isFinished) {
                    // User resumed drawing after finish timer fired — notify but keep existing strokes
                    isFinished = false
                    onDrawingResumed?.invoke()
                }
                // Cancel pending stop timer
                handler.removeCallbacks(stopDrawingRunnable)
                currentStroke = mutableListOf()
                currentStroke.add(PointF(event.x, event.y))
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                currentStroke.add(PointF(event.x, event.y))
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                currentStroke.add(PointF(event.x, event.y))
                allStrokes.add(currentStroke)
                currentStroke = mutableListOf()
                invalidate()
                // Start 1-second timer to detect end of drawing
                handler.postDelayed(stopDrawingRunnable, 1000)
            }
        }
        return true
    }

    fun getAllPathData(): List<List<LockPreferences.PointFData>> {
        return allStrokes.map { stroke ->
            stroke.map { LockPreferences.PointFData(it.x / width.toFloat().coerceAtLeast(1f),
                it.y / height.toFloat().coerceAtLeast(1f)) }
        }
    }

    /**
     * Compare user-drawn paths with saved paths using similarity score.
     * Returns true if similar enough.
     */
    fun verifyDrawing(savedPaths: List<List<LockPreferences.PointFData>>, threshold: Float = 0.72f): Boolean {
        if (savedPaths.isEmpty() || allStrokes.isEmpty()) return false
        val savedNorm = savedPaths.map { stroke ->
            stroke.map { PointF(it.x * width, it.y * height) }
        }
        val score = computeSimilarity(allStrokes, savedNorm)
        return score >= threshold
    }

    private fun computeSimilarity(drawn: List<List<PointF>>, saved: List<List<PointF>>): Float {
        val drawnFlat = drawn.flatten()
        val savedFlat = saved.flatten()
        if (drawnFlat.isEmpty() || savedFlat.isEmpty()) return 0f
        val drawnNorm = normalize(drawnFlat)
        val savedNorm = normalize(savedFlat)
        val sampleCount = 64
        val drawnResampled = resample(drawnNorm, sampleCount)
        val savedResampled = resample(savedNorm, sampleCount)
        var totalDist = 0f
        for (i in drawnResampled.indices) {
            val dx = drawnResampled[i].x - savedResampled[i].x
            val dy = drawnResampled[i].y - savedResampled[i].y
            totalDist += kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
        val avgDist = totalDist / sampleCount
        return (1f - (avgDist / 0.4f)).coerceIn(0f, 1f)
    }

    private fun normalize(points: List<PointF>): List<PointF> {
        val minX = points.minOf { it.x }
        val maxX = points.maxOf { it.x }
        val minY = points.minOf { it.y }
        val maxY = points.maxOf { it.y }
        val rangeX = (maxX - minX).coerceAtLeast(1f)
        val rangeY = (maxY - minY).coerceAtLeast(1f)
        return points.map { PointF((it.x - minX) / rangeX, (it.y - minY) / rangeY) }
    }

    private fun resample(points: List<PointF>, n: Int): List<PointF> {
        if (points.size <= 1) return List(n) { points.firstOrNull() ?: PointF(0f, 0f) }
        val result = mutableListOf<PointF>()
        for (i in 0 until n) {
            val t = i.toFloat() / (n - 1)
            val rawIdx = t * (points.size - 1)
            val idx = rawIdx.toInt().coerceIn(0, points.size - 2)
            val frac = rawIdx - idx
            val a = points[idx]
            val b = points[idx + 1]
            result.add(PointF(a.x + frac * (b.x - a.x), a.y + frac * (b.y - a.y)))
        }
        return result
    }

    fun clearAll() {
        handler.removeCallbacks(stopDrawingRunnable)
        isFinished = false
        allStrokes.clear()
        currentStroke.clear()
        invalidate()
    }
}
